/*
Copyright 2019 The Kubernetes Authors.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
*/

package azure

import (
	"context"
	"fmt"
	"testing"
	"time"

	"github.com/Azure/azure-sdk-for-go/sdk/resourcemanager/compute/armcompute/v7"
	"github.com/Azure/azure-sdk-for-go/sdk/resourcemanager/resources/armresources"
	"github.com/stretchr/testify/assert"
	"go.uber.org/mock/gomock"
	apiv1 "k8s.io/api/core/v1"
	v1 "k8s.io/apimachinery/pkg/apis/meta/v1"
	"k8s.io/utils/ptr"
	"sigs.k8s.io/cloud-provider-azure/pkg/azclient/virtualmachineclient/mock_virtualmachineclient"
	providerazureconsts "sigs.k8s.io/cloud-provider-azure/pkg/consts"
	"sigs.k8s.io/cluster-autoscaler/pkg/cloudprovider"
)

var (
	testValidProviderID0  = "/subscriptions/sub/resourceGroups/rg/providers/Microsoft.Compute/virtualMachines/as-vm-0"
	testValidProviderID1  = "/subscriptions/sub/resourceGroups/rg/providers/Microsoft.Compute/virtualMachines/as-vm-1"
	testInvalidProviderID = "/subscriptions/sub/resourceGroups/rg/providers/provider/virtualMachines/as-vm-0/"
)

func newTestAgentPool(manager *AzureManager, name string) *AgentPool {
	return &AgentPool{
		azureRef: azureRef{
			Name: name,
		},
		manager:    manager,
		minSize:    1,
		maxSize:    5,
		parameters: make(map[string]interface{}),
		template:   make(map[string]interface{}),
	}
}

func getExpectedVMs() []*armcompute.VirtualMachine {
	expectedVMs := []*armcompute.VirtualMachine{
		{
			Name: ptr.To("000-0-00000000-0"),
			ID:   ptr.To("/subscriptions/sub/resourceGroups/rg/providers/provider/0"),
			Tags: map[string]*string{"poolName": ptr.To("as")},
			Properties: &armcompute.VirtualMachineProperties{
				StorageProfile: &armcompute.StorageProfile{
					OSDisk: &armcompute.OSDisk{
						OSType: ptr.To(armcompute.OperatingSystemTypesLinux),
						Vhd:    &armcompute.VirtualHardDisk{URI: ptr.To("https://foo.blob/vhds/bar.vhd")},
					},
				},
				NetworkProfile: &armcompute.NetworkProfile{
					NetworkInterfaces: []*armcompute.NetworkInterfaceReference{
						{},
					},
				},
			},
		},
		{
			Name: ptr.To("00000000001"),
			ID:   ptr.To("/subscriptions/sub/resourceGroups/rg/providers/provider/0"),
			Tags: map[string]*string{"poolName": ptr.To("as")},
			Properties: &armcompute.VirtualMachineProperties{
				StorageProfile: &armcompute.StorageProfile{
					OSDisk: &armcompute.OSDisk{OSType: ptr.To(armcompute.OperatingSystemTypesWindows)},
				},
			},
		},
	}

	return expectedVMs
}

func TestInitialize(t *testing.T) {
	as := newTestAgentPool(newTestAzureManager(t), "as")

	err := as.initialize()
	assert.NoError(t, err)
	assert.NotNil(t, as.template)
}

func TestDeleteOutdatedDeployments(t *testing.T) {
	timeLayout := "2006-01-02 15:04:05"
	timeBenchMark, _ := time.Parse(timeLayout, "2000-01-01 00:00:00")

	testCases := []struct {
		deployments              map[string]armresources.DeploymentExtended
		expectedDeploymentsNames map[string]bool
		expectedErr              error
		desc                     string
	}{
		{
			deployments: map[string]armresources.DeploymentExtended{
				"non-cluster-autoscaler-0000": {
					Name: ptr.To("non-cluster-autoscaler-0000"),
					Properties: &armresources.DeploymentPropertiesExtended{
						ProvisioningState: ptr.To(armresources.ProvisioningStateSucceeded),
						Timestamp:         ptr.To(timeBenchMark.Add(2 * time.Minute)),
					},
				},
				"cluster-autoscaler-0000": {
					Name: ptr.To("cluster-autoscaler-0000"),
					Properties: &armresources.DeploymentPropertiesExtended{
						ProvisioningState: ptr.To(armresources.ProvisioningStateSucceeded),
						Timestamp:         ptr.To(timeBenchMark),
					},
				},
				"cluster-autoscaler-0001": {
					Name: ptr.To("cluster-autoscaler-0001"),
					Properties: &armresources.DeploymentPropertiesExtended{
						ProvisioningState: ptr.To(armresources.ProvisioningStateSucceeded),
						Timestamp:         ptr.To(timeBenchMark.Add(time.Minute)),
					},
				},
				"cluster-autoscaler-0002": {
					Name: ptr.To("cluster-autoscaler-0002"),
					Properties: &armresources.DeploymentPropertiesExtended{
						ProvisioningState: ptr.To(armresources.ProvisioningStateSucceeded),
						Timestamp:         ptr.To(timeBenchMark.Add(2 * time.Minute)),
					},
				},
			},
			expectedDeploymentsNames: map[string]bool{
				"non-cluster-autoscaler-0000": true,
				"cluster-autoscaler-0001":     true,
				"cluster-autoscaler-0002":     true,
			},
			expectedErr: nil,
			desc:        "cluster autoscaler provider azure should delete outdated deployments created by cluster autoscaler",
		},
	}

	for _, test := range testCases {
		testAS := newTestAgentPool(newTestAzureManager(t), "testAS")
		testAS.manager.azClient.deploymentClient = &DeploymentClientMock{
			FakeStore: test.deployments,
		}

		err := testAS.deleteOutdatedDeployments()
		assert.Equal(t, test.expectedErr, err, test.desc)
		existedDeployments, _ := testAS.manager.azClient.deploymentClient.List(context.Background(), "")
		existedDeploymentsNames := make(map[string]bool)
		for _, deployment := range existedDeployments {
			existedDeploymentsNames[*deployment.Name] = true
		}
		assert.Equal(t, test.expectedDeploymentsNames, existedDeploymentsNames, test.desc)
	}
}

func TestAgentPoolGetVMsFromCache(t *testing.T) {
	ctrl := gomock.NewController(t)
	defer ctrl.Finish()

	testAS := newTestAgentPool(newTestAzureManager(t), "testAS")
	expectedVMs := []*armcompute.VirtualMachine{
		{
			Tags: map[string]*string{"poolName": ptr.To("testAS")},
		},
	}

	mockVMClient := mock_virtualmachineclient.NewMockInterface(ctrl)
	testAS.manager.azClient.virtualMachinesClient = mockVMClient
	mockVMClient.EXPECT().List(gomock.Any(), testAS.manager.config.ResourceGroup).Return(expectedVMs, nil)
	testAS.manager.config.VMType = providerazureconsts.VMTypeStandard
	ac, err := newAzureCache(testAS.manager.azClient, refreshInterval, *testAS.manager.config)
	assert.NoError(t, err)
	testAS.manager.azureCache = ac

	vms, err := testAS.getVMsFromCache()
	assert.Equal(t, 1, len(vms))
	assert.NoError(t, err)
}

func TestGetVMIndexes(t *testing.T) {
	ctrl := gomock.NewController(t)
	defer ctrl.Finish()

	as := newTestAgentPool(newTestAzureManager(t), "as")
	expectedVMs := getExpectedVMs()
	mockVMClient := NewMockInterface(ctrl)
	as.manager.azClient.virtualMachinesClient = mockVMClient
	mockVMClient.EXPECT().List(gomock.Any(), as.manager.config.ResourceGroup).Return(expectedVMs, nil)
	as.manager.config.VMType = providerazureconsts.VMTypeStandard
	ac, err := newAzureCache(as.manager.azClient, refreshInterval, *as.manager.config)
	assert.NoError(t, err)
	as.manager.azureCache = ac

	sortedIndexes, indexToVM, err := as.GetVMIndexes()
	assert.NoError(t, err)
	assert.Equal(t, 2, len(sortedIndexes))
	assert.Equal(t, 2, len(indexToVM))

	expectedVMs[0].ID = ptr.To("foo")
	mockVMClient.EXPECT().List(gomock.Any(), as.manager.config.ResourceGroup).Return(expectedVMs, nil)
	err = as.manager.forceRefresh()
	assert.NoError(t, err)
	sortedIndexes, indexToVM, err = as.GetVMIndexes()
	expectedErr := fmt.Errorf("\"azure://foo\" isn't in Azure resource ID format")
	assert.Equal(t, expectedErr, err)
	assert.Nil(t, sortedIndexes)
	assert.Nil(t, indexToVM)

	expectedVMs[0].Name = ptr.To("foo")
	mockVMClient.EXPECT().List(gomock.Any(), as.manager.config.ResourceGroup).Return(expectedVMs, nil)
	err = as.manager.forceRefresh()
	sortedIndexes, indexToVM, err = as.GetVMIndexes()
	expectedErr = fmt.Errorf("resource name was missing from identifier")
	assert.Equal(t, expectedErr, err)
	assert.Nil(t, sortedIndexes)
	assert.Nil(t, indexToVM)
}

func TestGetCurSize(t *testing.T) {
	ctrl := gomock.NewController(t)
	defer ctrl.Finish()

	as := newTestAgentPool(newTestAzureManager(t), "as")
	as.curSize = 1
	expectedVMs := getExpectedVMs()
	mockVMClient := NewMockInterface(ctrl)
	as.manager.azClient.virtualMachinesClient = mockVMClient
	mockVMClient.EXPECT().List(gomock.Any(), as.manager.config.ResourceGroup).Return(expectedVMs, nil)
	as.manager.config.VMType = providerazureconsts.VMTypeStandard
	ac, err := newAzureCache(as.manager.azClient, refreshInterval, *as.manager.config)
	assert.NoError(t, err)
	as.manager.azureCache = ac

	as.lastRefresh = time.Now()
	curSize, err := as.getCurSize()
	assert.NoError(t, err)
	assert.Equal(t, int64(1), curSize)

	as.lastRefresh = time.Now().Add(-1 * 3 * time.Minute)
	curSize, err = as.getCurSize()
	assert.NoError(t, err)
	assert.Equal(t, int64(2), curSize)
}

func TestAgentPoolTargetSize(t *testing.T) {
	ctrl := gomock.NewController(t)
	defer ctrl.Finish()

	as := newTestAgentPool(newTestAzureManager(t), "as")
	mockVMClient := NewMockInterface(ctrl)
	as.manager.azClient.virtualMachinesClient = mockVMClient
	expectedVMs := getExpectedVMs()
	mockVMClient.EXPECT().List(gomock.Any(), as.manager.config.ResourceGroup).Return(expectedVMs, nil)
	as.manager.config.VMType = providerazureconsts.VMTypeStandard
	ac, err := newAzureCache(as.manager.azClient, refreshInterval, *as.manager.config)
	assert.NoError(t, err)
	as.manager.azureCache = ac

	as.lastRefresh = time.Now().Add(-1 * 15 * time.Second)
	size, err := as.getCurSize()
	assert.NoError(t, err)
	assert.Equal(t, int64(2), size)
}

func TestAgentPoolIncreaseSize(t *testing.T) {
	ctrl := gomock.NewController(t)
	defer ctrl.Finish()

	as := newTestAgentPool(newTestAzureManager(t), "as")
	mockVMClient := NewMockInterface(ctrl)
	as.manager.azClient.virtualMachinesClient = mockVMClient
	expectedVMs := getExpectedVMs()
	mockVMClient.EXPECT().List(gomock.Any(), as.manager.config.ResourceGroup).Return(expectedVMs, nil).MaxTimes(2)
	as.manager.config.VMType = providerazureconsts.VMTypeStandard
	ac, err := newAzureCache(as.manager.azClient, refreshInterval, *as.manager.config)
	assert.NoError(t, err)
	as.manager.azureCache = ac

	err = as.IncreaseSize(context.Background(), -1)
	expectedErr := fmt.Errorf("size increase must be positive")
	assert.Equal(t, expectedErr, err)

	mockVMClient.EXPECT().List(gomock.Any(), as.manager.config.ResourceGroup).Return(expectedVMs, nil).MaxTimes(2)
	err = as.manager.Refresh()
	assert.NoError(t, err)
	err = as.IncreaseSize(context.Background(), 4)
	expectedErr = fmt.Errorf("size increase too large - desired:6 max:5")

	err = as.IncreaseSize(context.Background(), 2)
	assert.NoError(t, err)
}

func TestAgentPoolDecreaseTargetSize(t *testing.T) {
	ctrl := gomock.NewController(t)
	defer ctrl.Finish()

	as := newTestAgentPool(newTestAzureManager(t), "as")
	as.curSize = 3
	mockVMClient := NewMockInterface(ctrl)
	as.manager.azClient.virtualMachinesClient = mockVMClient
	expectedVMs := getExpectedVMs()
	mockVMClient.EXPECT().List(gomock.Any(), as.manager.config.ResourceGroup).Return(expectedVMs, nil).MaxTimes(3)
	as.manager.config.VMType = providerazureconsts.VMTypeStandard
	ac, err := newAzureCache(as.manager.azClient, refreshInterval, *as.manager.config)
	assert.NoError(t, err)
	as.manager.azureCache = ac

	err = as.DecreaseTargetSize(context.Background(), -1)
	assert.NoError(t, err)
	assert.Equal(t, int64(2), as.curSize)

	mockVMClient.EXPECT().List(gomock.Any(), as.manager.config.ResourceGroup).Return(expectedVMs, nil).MaxTimes(2)
	err = as.manager.Refresh()
	assert.NoError(t, err)
	err = as.DecreaseTargetSize(context.Background(), -1)
	expectedErr := fmt.Errorf("attempt to delete existing nodes targetSize:2 delta:-1 existingNodes: 2")
	assert.Equal(t, expectedErr, err)
}

func TestAgentPoolBelongs(t *testing.T) {
	ctrl := gomock.NewController(t)
	defer ctrl.Finish()

	as := newTestAgentPool(newTestAzureManager(t), "as")
	as.manager.azureCache.instanceToNodeGroup[azureRef{Name: testValidProviderID0}] = as

	flag, err := as.Belongs(&apiv1.Node{Spec: apiv1.NodeSpec{ProviderID: testValidProviderID0}})
	assert.NoError(t, err)
	assert.True(t, flag)

	flag, err = as.Belongs(&apiv1.Node{
		Spec:       apiv1.NodeSpec{ProviderID: testInvalidProviderID},
		ObjectMeta: v1.ObjectMeta{Name: "node"},
	})
	expectedErr := fmt.Errorf("node doesn't belong to a known agent pool")
	assert.Equal(t, expectedErr, err)
	assert.False(t, flag)

	as1 := newTestAgentPool(newTestAzureManager(t), "as1")
	as1.manager.azureCache.instanceToNodeGroup[azureRef{Name: testValidProviderID0}] = as
	flag, err = as1.Belongs(&apiv1.Node{Spec: apiv1.NodeSpec{ProviderID: testValidProviderID0}})
	assert.NoError(t, err)
	assert.False(t, flag)
}

func TestDeleteInstances(t *testing.T) {
	ctrl := gomock.NewController(t)
	defer ctrl.Finish()

	as := newTestAgentPool(newTestAzureManager(t), "as")
	as1 := newTestAgentPool(newTestAzureManager(t), "as1")
	as.manager.azureCache.instanceToNodeGroup[azureRef{Name: testValidProviderID0}] = as
	as.manager.azureCache.instanceToNodeGroup[azureRef{Name: testValidProviderID1}] = as1
	as.manager.azureCache.instanceToNodeGroup[azureRef{Name: testInvalidProviderID}] = as

	mockVMClient := NewMockInterface(ctrl)
	as.manager.azClient.virtualMachinesClient = mockVMClient

	mockSAClient := NewMockStorageAccountClient(ctrl)
	as.manager.azClient.storageAccountsClient = mockSAClient

	err := as.DeleteInstances([]*azureRef{})
	assert.NoError(t, err)

	instances := []*azureRef{
		{Name: "foo"},
	}
	err = as.DeleteInstances(instances)
	expectedErr := fmt.Errorf("\"foo\" isn't in Azure resource ID format")
	assert.Equal(t, expectedErr, err)

	instances = []*azureRef{
		{Name: testValidProviderID0},
		{Name: "foo"},
	}
	err = as.DeleteInstances(instances)
	assert.Equal(t, expectedErr, err)

	instances = []*azureRef{
		{Name: testInvalidProviderID},
	}
	err = as.DeleteInstances(instances)
	expectedErr = fmt.Errorf("resource name was missing from identifier")
	assert.Equal(t, expectedErr, err)

	instances = []*azureRef{
		{Name: testValidProviderID0},
		{Name: testValidProviderID1},
	}

	err = as.DeleteInstances(instances)
	expectedErr = fmt.Errorf("cannot delete instance (%s) which don't belong to the same node pool (\"as\")", testValidProviderID1)
	assert.Equal(t, expectedErr, err)
}

func TestForceDeleteNodes(t *testing.T) {
	ctrl := gomock.NewController(t)
	defer ctrl.Finish()

	as := newTestAgentPool(newTestAzureManager(t), "as")
	as1 := newTestAgentPool(newTestAzureManager(t), "as1")
	as.manager.azureCache.instanceToNodeGroup[azureRef{Name: testValidProviderID0}] = as
	as.manager.azureCache.instanceToNodeGroup[azureRef{Name: testValidProviderID1}] = as1
	as.manager.azureCache.instanceToNodeGroup[azureRef{Name: testInvalidProviderID}] = as

	mockVMClient := NewMockInterface(ctrl)
	as.manager.azClient.virtualMachinesClient = mockVMClient

	mockSAClient := NewMockStorageAccountClient(ctrl)
	as.manager.azClient.storageAccountsClient = mockSAClient

	err := as.ForceDeleteNodes(context.Background(), []*apiv1.Node{})
	assert.NoError(t, err)

	nodes := []*apiv1.Node{
		{
			Spec:       apiv1.NodeSpec{ProviderID: testInvalidProviderID},
			ObjectMeta: v1.ObjectMeta{Name: "node"},
		},
	}
	err = as.ForceDeleteNodes(context.Background(), nodes)
	expectedErr := fmt.Errorf("resource name was missing from identifier")
	assert.Equal(t, expectedErr, err)

	nodes = []*apiv1.Node{
		{
			Spec:       apiv1.NodeSpec{ProviderID: testValidProviderID1},
			ObjectMeta: v1.ObjectMeta{Name: "node1"},
		},
	}
	err = as.ForceDeleteNodes(context.Background(), nodes)
	expectedErr = fmt.Errorf("node1 belongs to a different asg than as")
	assert.Equal(t, expectedErr, err)
}

func TestAgentPoolDeleteNodes(t *testing.T) {
	ctrl := gomock.NewController(t)
	defer ctrl.Finish()

	as := newTestAgentPool(newTestAzureManager(t), "as")
	as.manager.azureCache.instanceToNodeGroup[azureRef{Name: testValidProviderID0}] = as
	expectedVMs := getExpectedVMs()
	mockVMClient := NewMockInterface(ctrl)
	as.manager.azClient.virtualMachinesClient = mockVMClient
	mockSAClient := NewMockStorageAccountClient(ctrl)
	as.manager.azClient.storageAccountsClient = mockSAClient
	mockVMClient.EXPECT().List(gomock.Any(), as.manager.config.ResourceGroup).Return(expectedVMs, nil)
	as.manager.config.VMType = providerazureconsts.VMTypeStandard
	ac, err := newAzureCache(as.manager.azClient, refreshInterval, *as.manager.config)
	as.manager.config.VMType = providerazureconsts.VMTypeVMSS
	assert.NoError(t, err)
	as.manager.azureCache = ac

	err = as.DeleteNodes(context.Background(), []*apiv1.Node{
		{
			Spec:       apiv1.NodeSpec{ProviderID: testInvalidProviderID},
			ObjectMeta: v1.ObjectMeta{Name: "node"},
		},
	})
	expectedErr := fmt.Errorf("node doesn't belong to a known agent pool")
	assert.Equal(t, expectedErr, err)

	as1 := newTestAgentPool(newTestAzureManager(t), "as1")
	as.manager.azureCache.instanceToNodeGroup[azureRef{Name: testValidProviderID0}] = as1
	err = as.DeleteNodes(context.Background(), []*apiv1.Node{
		{
			Spec:       apiv1.NodeSpec{ProviderID: testValidProviderID0},
			ObjectMeta: v1.ObjectMeta{Name: "node"},
		},
	})
	expectedErr = fmt.Errorf("node belongs to a different asg than as")
	assert.Equal(t, expectedErr, err)

	as.minSize = 3
	err = as.DeleteNodes(context.Background(), []*apiv1.Node{})
	expectedErr = fmt.Errorf("min size reached, nodes will not be deleted")
	assert.Equal(t, expectedErr, err)
}

func TestAgentPoolNodes(t *testing.T) {
	ctrl := gomock.NewController(t)
	defer ctrl.Finish()

	as := newTestAgentPool(newTestAzureManager(t), "as")
	expectedVMs := []*armcompute.VirtualMachine{
		{
			Tags: map[string]*string{"poolName": ptr.To("as")},
			ID:   ptr.To(""),
		},
		{
			Tags: map[string]*string{"poolName": ptr.To("as")},
			ID:   &testValidProviderID0,
			Properties: &armcompute.VirtualMachineProperties{
				ProvisioningState: new("Succeeded"),
			},
		},
	}

	mockVMClient := NewMockInterface(ctrl)
	as.manager.azClient.virtualMachinesClient = mockVMClient
	mockVMClient.EXPECT().List(gomock.Any(), as.manager.config.ResourceGroup).Return(expectedVMs, nil)
	as.manager.config.VMType = providerazureconsts.VMTypeStandard
	ac, err := newAzureCache(as.manager.azClient, refreshInterval, *as.manager.config)
	assert.NoError(t, err)
	as.manager.azureCache = ac

	nodes, err := as.Nodes(context.Background())
	assert.NoError(t, err)
	assert.Equal(t, 1, len(nodes))
	assert.Equal(t, cloudprovider.InstanceRunning, nodes[0].Status.State)

	expectedVMs[1].Properties = &armcompute.VirtualMachineProperties{ProvisioningState: ptr.To(VMProvisioningStateDeleting)}
	as.manager.azureCache.virtualMachines["as"] = expectedVMs
	nodes, err = as.Nodes(context.Background())
	assert.NoError(t, err)
	assert.Equal(t, cloudprovider.InstanceDeleting, nodes[0].Status.State)

	expectedVMs = []*armcompute.VirtualMachine{
		{
			Tags: map[string]*string{"poolName": ptr.To("as")},
			ID:   ptr.To("foo"),
		},
	}
	mockVMClient.EXPECT().List(gomock.Any(), as.manager.config.ResourceGroup).Return(expectedVMs, nil)
	err = as.manager.forceRefresh()
	assert.NoError(t, err)
	nodes, err = as.Nodes(context.Background())
	expectedErr := fmt.Errorf("\"azure://foo\" isn't in Azure resource ID format")
	assert.Equal(t, expectedErr, err)
	assert.Nil(t, nodes)
}

func TestAgentPoolDeleteInstancesProactivelyMarksDeletion(t *testing.T) {
	ctrl := gomock.NewController(t)
	defer ctrl.Finish()

	as := newTestAgentPool(newTestAzureManager(t), "as")
	as.manager.azureCache.instanceToNodeGroup[azureRef{Name: testValidProviderID0}] = as

	mockVMClient := NewMockInterface(ctrl)
	as.manager.azClient.virtualMachinesClient = mockVMClient

	vmName, err := resourceName(testValidProviderID0)
	assert.NoError(t, err)
	mockVMClient.EXPECT().Get(gomock.Any(), as.manager.config.ResourceGroup, vmName, nil).DoAndReturn(
		func(ctx context.Context, resourceGroupName, vmName string, expand *string) (*armcompute.VirtualMachine, error) {
			hasInstance, hasInstanceErr := as.manager.azureCache.HasInstance(testValidProviderID0)
			assert.False(t, hasInstance)
			assert.NoError(t, hasInstanceErr)
			return &armcompute.VirtualMachine{
				Properties: &armcompute.VirtualMachineProperties{
					StorageProfile: &armcompute.StorageProfile{OSDisk: &armcompute.OSDisk{ManagedDisk: &armcompute.ManagedDiskParameters{}}},
				},
			}, nil
		})
	mockVMClient.EXPECT().Delete(gomock.Any(), as.manager.config.ResourceGroup, vmName).Return(nil)

	hasInstance, err := as.manager.azureCache.HasInstance(testValidProviderID0)
	assert.True(t, hasInstance)
	assert.NoError(t, err)

	err = as.DeleteInstances([]*azureRef{{Name: testValidProviderID0}})
	assert.NoError(t, err)
}

func TestAgentPoolDeleteInstancesStrictCacheDoesNotProactivelyMarkDeletion(t *testing.T) {
	ctrl := gomock.NewController(t)
	defer ctrl.Finish()

	as := newTestAgentPool(newTestAzureManager(t), "as")
	as.manager.config.StrictCacheUpdates = true
	as.manager.azureCache.instanceToNodeGroup[azureRef{Name: testValidProviderID0}] = as

	mockVMClient := NewMockInterface(ctrl)
	as.manager.azClient.virtualMachinesClient = mockVMClient

	vmName, err := resourceName(testValidProviderID0)
	assert.NoError(t, err)
	mockVMClient.EXPECT().Get(gomock.Any(), as.manager.config.ResourceGroup, vmName, nil).DoAndReturn(
		func(ctx context.Context, resourceGroupName, vmName string, expand *string) (*armcompute.VirtualMachine, error) {
			hasInstance, hasInstanceErr := as.manager.azureCache.HasInstance(testValidProviderID0)
			assert.True(t, hasInstance)
			assert.NoError(t, hasInstanceErr)
			return &armcompute.VirtualMachine{
				Properties: &armcompute.VirtualMachineProperties{
					StorageProfile: &armcompute.StorageProfile{OSDisk: &armcompute.OSDisk{ManagedDisk: &armcompute.ManagedDiskParameters{}}},
				},
			}, nil
		})
	mockVMClient.EXPECT().Delete(gomock.Any(), as.manager.config.ResourceGroup, vmName).Return(nil)

	hasInstance, err := as.manager.azureCache.HasInstance(testValidProviderID0)
	assert.True(t, hasInstance)
	assert.NoError(t, err)

	err = as.DeleteInstances([]*azureRef{{Name: testValidProviderID0}})
	assert.NoError(t, err)

	// Strict cache mode should not mutate instance state proactively; the instance
	// remains present until the next refresh reflects Azure state.
	hasInstance, err = as.manager.azureCache.HasInstance(testValidProviderID0)
	assert.True(t, hasInstance)
	assert.NoError(t, err)
}
