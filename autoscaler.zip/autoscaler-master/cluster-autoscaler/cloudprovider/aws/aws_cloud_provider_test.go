/*
Copyright 2016 The Kubernetes Authors.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
*/

package aws

import (
	"context"
	"fmt"
	"testing"

	"github.com/aws/aws-sdk-go-v2/aws"
	"github.com/aws/aws-sdk-go-v2/service/autoscaling"
	autoscalingtypes "github.com/aws/aws-sdk-go-v2/service/autoscaling/types"
	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/mock"
	apiv1 "k8s.io/api/core/v1"
	storagev1 "k8s.io/api/storage/v1"
	metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"
	"sigs.k8s.io/cluster-autoscaler/pkg/cloudprovider"
	testprovider "sigs.k8s.io/cluster-autoscaler/pkg/cloudprovider/test"
	ca_context "sigs.k8s.io/cluster-autoscaler/pkg/context"
	coreoptions "sigs.k8s.io/cluster-autoscaler/pkg/core/options"
	"sigs.k8s.io/cluster-autoscaler/pkg/processors/customresources"
	"sigs.k8s.io/cluster-autoscaler/pkg/processors/nodeinfosprovider"
	csisnapshot "sigs.k8s.io/cluster-autoscaler/pkg/simulator/csi/snapshot"
	"sigs.k8s.io/cluster-autoscaler/pkg/simulator/framework"
)

var testAwsManager = &AwsManager{
	asgCache: &asgCache{
		registeredAsgs: make(map[AwsRef]*asg, 0),
		asgToInstances: make(map[AwsRef][]AwsInstanceRef),
		instanceToAsg:  make(map[AwsInstanceRef]*asg),
		interrupt:      make(chan struct{}),
		awsService:     &testAwsService,
	},
	awsService: testAwsService,
}

func newTestAwsManagerWithMockServices(mockAutoScaling autoScalingI, mockEC2 ec2I, mockEKS eksI, autoDiscoverySpecs []asgAutoDiscoveryConfig, instanceStatus map[AwsInstanceRef]*string) *AwsManager {
	awsService := awsWrapper{mockAutoScaling, mockEC2, mockEKS}
	mgr := &AwsManager{
		awsService: awsService,
		asgCache: &asgCache{
			registeredAsgs:        make(map[AwsRef]*asg, 0),
			asgToInstances:        make(map[AwsRef][]AwsInstanceRef),
			instanceToAsg:         make(map[AwsInstanceRef]*asg),
			asgInstanceTypeCache:  newAsgInstanceTypeCache(&awsService),
			explicitlyConfigured:  make(map[AwsRef]bool),
			interrupt:             make(chan struct{}),
			asgAutoDiscoverySpecs: autoDiscoverySpecs,
			awsService:            &awsService,
			autoscalingOptions:    make(map[AwsRef]map[string]string),
		},
	}

	if instanceStatus != nil {
		mgr.asgCache.instanceStatus = instanceStatus
	}
	return mgr
}

func newTestAwsManagerWithAsgs(t *testing.T, mockAutoScaling autoScalingI, mockEC2 ec2I, specs []string) *AwsManager {
	m := newTestAwsManagerWithMockServices(mockAutoScaling, mockEC2, nil, nil, nil)
	m.asgCache.parseExplicitAsgs(specs)
	return m
}

func newTestAwsManagerWithAutoAsgs(t *testing.T, mockAutoScaling autoScalingI, mockEC2 ec2I, specs []string, autoDiscoverySpecs []asgAutoDiscoveryConfig) *AwsManager {
	m := newTestAwsManagerWithMockServices(mockAutoScaling, mockEC2, nil, autoDiscoverySpecs, nil)
	m.asgCache.parseExplicitAsgs(specs)
	return m
}

func testNamedDescribeAutoScalingGroupsOutput(groupName string, desiredCap int32, instanceIds ...string) *autoscaling.DescribeAutoScalingGroupsOutput {
	var instances []autoscalingtypes.Instance
	for _, id := range instanceIds {
		instances = append(instances, autoscalingtypes.Instance{
			InstanceId:       aws.String(id),
			AvailabilityZone: aws.String("us-east-1a"),
			LifecycleState:   autoscalingtypes.LifecycleStateInService,
		})
	}
	return &autoscaling.DescribeAutoScalingGroupsOutput{
		AutoScalingGroups: []autoscalingtypes.AutoScalingGroup{
			{
				AutoScalingGroupName: aws.String(groupName),
				DesiredCapacity:      aws.Int32(desiredCap),
				MinSize:              aws.Int32(1),
				MaxSize:              aws.Int32(5),
				Instances:            instances,
				AvailabilityZones:    []string{"us-east-1a"},
			},
		},
	}
}

func testSetASGInstanceLifecycle(asg *autoscaling.DescribeAutoScalingGroupsOutput, lifecycleState autoscalingtypes.LifecycleState) *autoscaling.DescribeAutoScalingGroupsOutput {
	for _, asg := range asg.AutoScalingGroups {
		for i := range asg.Instances {
			asg.Instances[i].LifecycleState = lifecycleState
		}
	}
	return asg
}

func testProvider(t *testing.T, m *AwsManager) *awsCloudProvider {
	resourceLimiter := cloudprovider.NewResourceLimiter(
		map[string]int64{cloudprovider.ResourceNameCores: 1, cloudprovider.ResourceNameMemory: 10000000},
		map[string]int64{cloudprovider.ResourceNameCores: 10, cloudprovider.ResourceNameMemory: 100000000})

	provider, err := BuildAwsCloudProvider(m, resourceLimiter)
	assert.NoError(t, err)
	return provider.(*awsCloudProvider)
}

func TestBuildAwsCloudProvider(t *testing.T) {
	resourceLimiter := cloudprovider.NewResourceLimiter(
		map[string]int64{cloudprovider.ResourceNameCores: 1, cloudprovider.ResourceNameMemory: 10000000},
		map[string]int64{cloudprovider.ResourceNameCores: 10, cloudprovider.ResourceNameMemory: 100000000})

	_, err := BuildAwsCloudProvider(testAwsManager, resourceLimiter)
	assert.NoError(t, err)
}

func TestInstanceTypeFallback(t *testing.T) {
	resourceLimiter := cloudprovider.NewResourceLimiter(
		map[string]int64{cloudprovider.ResourceNameCores: 1, cloudprovider.ResourceNameMemory: 10000000},
		map[string]int64{cloudprovider.ResourceNameCores: 10, cloudprovider.ResourceNameMemory: 100000000})

	do := cloudprovider.NodeGroupDiscoveryOptions{}
	opts := &coreoptions.AutoscalerOptions{}

	t.Setenv("AWS_REGION", "non-existent-region")

	// This test ensures that no klog.Fatalf calls occur when constructing the AWS cloud provider.  Specifically it is
	// intended to ensure that instance type fallback works correctly in the event of an error enumerating instance
	// types.
	_ = BuildAWS(opts, do, resourceLimiter)
}

func TestName(t *testing.T) {
	provider := testProvider(t, testAwsManager)
	assert.Equal(t, provider.Name(), ProviderName)
}

func TestNodeGroups(t *testing.T) {
	provider := testProvider(t, newTestAwsManagerWithAsgs(t, testAwsService, nil, []string{"1:5:test-asg"}))

	nodeGroups := provider.NodeGroups(context.Background())
	assert.Equal(t, len(nodeGroups), 1)
	assert.Equal(t, nodeGroups[0].Id(), "test-asg")
	assert.Equal(t, nodeGroups[0].MinSize(context.Background()), 1)
	assert.Equal(t, nodeGroups[0].MaxSize(context.Background()), 5)
}

func TestAutoDiscoveredNodeGroups(t *testing.T) {
	a := &autoScalingMock{}
	provider := testProvider(t, newTestAwsManagerWithAutoAsgs(t, a, nil, []string{}, []asgAutoDiscoveryConfig{
		{
			Tags: map[string]string{"test": ""},
		},
	}))

	a.On("DescribeAutoScalingGroups",
		mock.Anything,
		&autoscaling.DescribeAutoScalingGroupsInput{
			Filters: []autoscalingtypes.Filter{
				{Name: aws.String("tag-key"), Values: []string{"test"}},
			},
			MaxRecords: aws.Int32(maxRecordsReturnedByAPI),
		},
	).Return(testNamedDescribeAutoScalingGroupsOutput("auto-asg", 1, "test-instance-id"), nil)

	provider.Refresh(context.Background())

	nodeGroups := provider.NodeGroups(context.Background())
	assert.Equal(t, len(nodeGroups), 1)
	assert.Equal(t, nodeGroups[0].Id(), "auto-asg")
	assert.Equal(t, nodeGroups[0].MinSize(context.Background()), 1)
	assert.Equal(t, nodeGroups[0].MaxSize(context.Background()), 5)
}

func TestNodeGroupForNode(t *testing.T) {
	node := &apiv1.Node{
		Spec: apiv1.NodeSpec{
			ProviderID: "aws:///us-east-1a/test-instance-id",
		},
	}
	a := &autoScalingMock{}
	provider := testProvider(t, newTestAwsManagerWithAsgs(t, a, nil, []string{"1:5:test-asg"}))

	a.On("DescribeAutoScalingGroups",
		mock.Anything,
		&autoscaling.DescribeAutoScalingGroupsInput{
			AutoScalingGroupNames: []string{"test-asg"},
			MaxRecords:            aws.Int32(maxRecordsReturnedByAPI),
		},
	).Return(testNamedDescribeAutoScalingGroupsOutput("test-asg", 1, "test-instance-id"), nil)

	provider.Refresh(context.Background())

	group, err := provider.NodeGroupForNode(context.Background(), node)

	assert.NoError(t, err)
	assert.Equal(t, group.Id(), "test-asg")
	assert.Equal(t, group.MinSize(context.Background()), 1)
	assert.Equal(t, group.MaxSize(context.Background()), 5)

	nodes, err := group.Nodes(context.Background())

	assert.NoError(t, err)

	assert.Equal(t, []cloudprovider.Instance{{Id: "aws:///us-east-1a/test-instance-id"}}, nodes)
	a.AssertNumberOfCalls(t, "DescribeAutoScalingGroups", 1)

	// test node in cluster that is not in a group managed by cluster autoscaler
	nodeNotInGroup := &apiv1.Node{
		Spec: apiv1.NodeSpec{
			ProviderID: "aws:///us-east-1a/test-instance-id-not-in-group",
		},
	}

	group, err = provider.NodeGroupForNode(context.Background(), nodeNotInGroup)

	assert.NoError(t, err)
	assert.Nil(t, group)
	a.AssertNumberOfCalls(t, "DescribeAutoScalingGroups", 1)
}

func TestNodeGroupForNodeWithNoProviderId(t *testing.T) {
	node := &apiv1.Node{
		Spec: apiv1.NodeSpec{
			ProviderID: "",
		},
	}
	a := &autoScalingMock{}
	provider := testProvider(t, newTestAwsManagerWithAsgs(t, a, nil, []string{"1:5:test-asg"}))
	group, err := provider.NodeGroupForNode(context.Background(), node)

	assert.NoError(t, err)
	assert.Equal(t, group, nil)
}

func TestNodeGroupForNodeWithHybridNode(t *testing.T) {
	hybridNode := &apiv1.Node{
		Spec: apiv1.NodeSpec{
			ProviderID: "eks-hybrid:///us-west-2/my-cluster/my-node-1",
		},
	}
	a := &autoScalingMock{}
	provider := testProvider(t, newTestAwsManagerWithAsgs(t, a, nil, []string{"1:5:test-asg"}))
	group, err := provider.NodeGroupForNode(context.Background(), hybridNode)

	assert.NoError(t, err)
	assert.Nil(t, group)
}

func TestAwsRefFromProviderId(t *testing.T) {
	tests := []struct {
		provID string
		expErr bool
		expRef *AwsInstanceRef
	}{
		{
			provID: "aws123",
			expErr: true,
		},
		{
			provID: "aws://test-az/test-instance-id",
			expErr: true,
		},
		{

			provID: "aws:///us-east-1a/i-260942b3",
			expErr: false,
			expRef: &AwsInstanceRef{
				Name:       "i-260942b3",
				ProviderID: "aws:///us-east-1a/i-260942b3",
			},
		},
		{
			provID: "aws:///us-east-1a/i-placeholder-some.arbitrary.cluster.local",
			expErr: false,
			expRef: &AwsInstanceRef{
				Name:       "i-placeholder-some.arbitrary.cluster.local",
				ProviderID: "aws:///us-east-1a/i-placeholder-some.arbitrary.cluster.local",
			},
		},
		{
			// ref: https://github.com/kubernetes/autoscaler/issues/2285
			provID: "aws:///eu-central-1c/i-placeholder-K3-EKS-spotr5xlasgsubnet02af43b02922e710f-10QH9H0C8PG7O-14",
			expErr: false,
			expRef: &AwsInstanceRef{
				Name:       "i-placeholder-K3-EKS-spotr5xlasgsubnet02af43b02922e710f-10QH9H0C8PG7O-14",
				ProviderID: "aws:///eu-central-1c/i-placeholder-K3-EKS-spotr5xlasgsubnet02af43b02922e710f-10QH9H0C8PG7O-14",
			},
		},
		{
			// ref: https://github.com/kubernetes/autoscaler/issues/8305
			provID: "aws:///us-east-1a/i-placeholder-some/arbitrary/cluster/local",
			expErr: false,
			expRef: &AwsInstanceRef{
				Name:       "i-placeholder-some/arbitrary/cluster/local",
				ProviderID: "aws:///us-east-1a/i-placeholder-some/arbitrary/cluster/local",
			},
		},
		{
			// A non-placeholder instance name that happens to contain the
			// placeholder prefix as a substring must still be routed through
			// the ordinary-ID branch (matches[2]), not the placeholder branch.
			provID: "aws:///us-east-1a/i-foo-i-placeholder-bar",
			expErr: false,
			expRef: &AwsInstanceRef{
				Name:       "i-foo-i-placeholder-bar",
				ProviderID: "aws:///us-east-1a/i-foo-i-placeholder-bar",
			},
		},
	}

	for _, test := range tests {
		got, err := AwsRefFromProviderId(test.provID)
		if test.expErr {
			assert.Error(t, err)
		} else {
			assert.NoError(t, err)
			assert.Equal(t, got, test.expRef)
		}
	}
}

func TestTargetSize(t *testing.T) {
	a := &autoScalingMock{}
	provider := testProvider(t, newTestAwsManagerWithAsgs(t, a, nil, []string{"1:5:test-asg"}))
	asgs := provider.NodeGroups(context.Background())

	a.On("DescribeAutoScalingGroups",
		mock.Anything,
		&autoscaling.DescribeAutoScalingGroupsInput{
			AutoScalingGroupNames: []string{"test-asg"},
			MaxRecords:            aws.Int32(maxRecordsReturnedByAPI),
		},
	).Return(testNamedDescribeAutoScalingGroupsOutput("test-asg", 2, "test-instance-id", "second-test-instance-id"), nil)

	provider.Refresh(context.Background())

	targetSize, err := asgs[0].TargetSize(context.Background())
	assert.Equal(t, targetSize, 2)
	assert.NoError(t, err)

	a.AssertNumberOfCalls(t, "DescribeAutoScalingGroups", 1)
}

func TestIncreaseSize(t *testing.T) {
	a := &autoScalingMock{}
	provider := testProvider(t, newTestAwsManagerWithAsgs(t, a, nil, []string{"1:5:test-asg"}))
	asgs := provider.NodeGroups(context.Background())

	a.On("SetDesiredCapacity", mock.Anything,
		&autoscaling.SetDesiredCapacityInput{
			AutoScalingGroupName: aws.String(asgs[0].Id()),
			DesiredCapacity:      aws.Int32(3),
			HonorCooldown:        aws.Bool(false),
		}).Return(&autoscaling.SetDesiredCapacityOutput{}, nil)

	a.On("DescribeAutoScalingGroups",
		mock.Anything,
		&autoscaling.DescribeAutoScalingGroupsInput{
			AutoScalingGroupNames: []string{"test-asg"},
			MaxRecords:            aws.Int32(maxRecordsReturnedByAPI),
		},
	).Return(testNamedDescribeAutoScalingGroupsOutput("test-asg", 2, "test-instance-id", "second-test-instance-id"), nil)

	provider.Refresh(context.Background())

	initialSize, err := asgs[0].TargetSize(context.Background())
	assert.NoError(t, err)
	assert.Equal(t, 2, initialSize)

	err = asgs[0].IncreaseSize(context.Background(), 1)
	assert.NoError(t, err)
	a.AssertNumberOfCalls(t, "SetDesiredCapacity", 1)
	a.AssertNumberOfCalls(t, "DescribeAutoScalingGroups", 1)

	newSize, err := asgs[0].TargetSize(context.Background())
	assert.NoError(t, err)
	assert.Equal(t, 3, newSize)
}

func TestBelongs(t *testing.T) {
	a := &autoScalingMock{}
	provider := testProvider(t, newTestAwsManagerWithAsgs(t, a, nil, []string{"1:5:test-asg"}))
	asgs := provider.NodeGroups(context.Background())

	a.On("DescribeAutoScalingGroups",
		mock.Anything,
		&autoscaling.DescribeAutoScalingGroupsInput{
			AutoScalingGroupNames: []string{asgs[0].Id()},
			MaxRecords:            aws.Int32(maxRecordsReturnedByAPI),
		},
	).Return(testNamedDescribeAutoScalingGroupsOutput("test-asg", 1, "test-instance-id"), nil)

	provider.Refresh(context.Background())

	invalidNode := &apiv1.Node{
		Spec: apiv1.NodeSpec{
			ProviderID: "aws:///us-east-1a/invalid-instance-id",
		},
	}
	_, err := asgs[0].(*AwsNodeGroup).Belongs(invalidNode)
	assert.Error(t, err)
	a.AssertNumberOfCalls(t, "DescribeAutoScalingGroups", 1)

	validNode := &apiv1.Node{
		Spec: apiv1.NodeSpec{
			ProviderID: "aws:///us-east-1a/test-instance-id",
		},
	}
	belongs, err := asgs[0].(*AwsNodeGroup).Belongs(validNode)
	assert.Equal(t, belongs, true)
	assert.NoError(t, err)
	// As "test-instance-id" is already known to be managed by test-asg since
	// the first `Belongs` call, no additional DescribAutoScalingGroups
	// call is made.
	a.AssertNumberOfCalls(t, "DescribeAutoScalingGroups", 1)
}

func TestDeleteNodes(t *testing.T) {
	a := &autoScalingMock{}
	provider := testProvider(t, newTestAwsManagerWithAsgs(t, a, nil, []string{"1:5:test-asg"}))
	asgs := provider.NodeGroups(context.Background())
	var expectedInstancesCount int32 = 2

	a.On("TerminateInstanceInAutoScalingGroup",
		mock.Anything,
		&autoscaling.TerminateInstanceInAutoScalingGroupInput{
			InstanceId:                     aws.String("test-instance-id"),
			ShouldDecrementDesiredCapacity: aws.Bool(true),
		},
	).Return(&autoscaling.TerminateInstanceInAutoScalingGroupOutput{
		Activity: &autoscalingtypes.Activity{Description: aws.String("Deleted instance")},
	}, nil)

	// Look up the current number of instances...
	a.On("DescribeAutoScalingGroups",
		mock.Anything,
		&autoscaling.DescribeAutoScalingGroupsInput{
			AutoScalingGroupNames: []string{"test-asg"},
			MaxRecords:            aws.Int32(maxRecordsReturnedByAPI),
		},
	).Run(func(args mock.Arguments) {
		expectedInstancesCount = 1
	},
	).Return(testNamedDescribeAutoScalingGroupsOutput("test-asg", expectedInstancesCount, "test-instance-id", "second-test-instance-id"), nil)

	provider.Refresh(context.Background())

	initialSize, err := asgs[0].TargetSize(context.Background())
	assert.NoError(t, err)
	assert.Equal(t, 2, initialSize)

	node := &apiv1.Node{
		Spec: apiv1.NodeSpec{
			ProviderID: "aws:///us-east-1a/test-instance-id",
		},
	}
	err = asgs[0].DeleteNodes(context.Background(), []*apiv1.Node{node})
	assert.NoError(t, err)
	a.AssertNumberOfCalls(t, "TerminateInstanceInAutoScalingGroup", 1)
	a.AssertNumberOfCalls(t, "DescribeAutoScalingGroups", 1)

	newSize, err := asgs[0].TargetSize(context.Background())
	assert.NoError(t, err)
	assert.Equal(t, 1, newSize)
}

func TestDeleteNodesTerminatingInstances(t *testing.T) {
	a := &autoScalingMock{}
	provider := testProvider(t, newTestAwsManagerWithAsgs(t, a, nil, []string{"1:5:test-asg"}))
	asgs := provider.NodeGroups(context.Background())

	a.On("TerminateInstanceInAutoScalingGroup",
		mock.Anything,
		&autoscaling.TerminateInstanceInAutoScalingGroupInput{
			InstanceId:                     aws.String("test-instance-id"),
			ShouldDecrementDesiredCapacity: aws.Bool(true),
		},
	).Return(
		&autoscaling.TerminateInstanceInAutoScalingGroupOutput{
			Activity: &autoscalingtypes.Activity{Description: aws.String("Deleted instance")},
		},
		nil,
	)

	// Look up the current number of instances...
	var expectedInstancesCount int32 = 2
	a.On("DescribeAutoScalingGroups",
		mock.Anything,
		&autoscaling.DescribeAutoScalingGroupsInput{
			AutoScalingGroupNames: []string{"test-asg"},
			MaxRecords:            aws.Int32(maxRecordsReturnedByAPI),
		},
	).Run(func(args mock.Arguments) {
		// we expect the instance count to be 1 after the call to DeleteNodes
		expectedInstancesCount = 1
	}).Return(testSetASGInstanceLifecycle(testNamedDescribeAutoScalingGroupsOutput("test-asg", expectedInstancesCount, "test-instance-id", "second-test-instance-id"), autoscalingtypes.LifecycleStateTerminatingWait), nil)

	provider.Refresh(context.Background())

	initialSize, err := asgs[0].TargetSize(context.Background())
	assert.NoError(t, err)
	assert.Equal(t, 2, initialSize)

	node := &apiv1.Node{
		Spec: apiv1.NodeSpec{
			ProviderID: "aws:///us-east-1a/test-instance-id",
		},
	}
	err = asgs[0].DeleteNodes(context.Background(), []*apiv1.Node{node})
	assert.NoError(t, err)
	a.AssertNumberOfCalls(t, "TerminateInstanceInAutoScalingGroup", 0) // instances which are terminating don't need to be terminated again
	a.AssertNumberOfCalls(t, "DescribeAutoScalingGroups", 1)

	newSize, err := asgs[0].TargetSize(context.Background())
	assert.NoError(t, err)
	assert.Equal(t, 2, newSize)
}

func TestDeleteNodesTerminatedInstances(t *testing.T) {
	a := &autoScalingMock{}
	provider := testProvider(t, newTestAwsManagerWithAsgs(t, a, nil, []string{"1:5:test-asg"}))
	asgs := provider.NodeGroups(context.Background())

	a.On("TerminateInstanceInAutoScalingGroup",
		mock.Anything,
		&autoscaling.TerminateInstanceInAutoScalingGroupInput{
			InstanceId:                     aws.String("test-instance-id"),
			ShouldDecrementDesiredCapacity: aws.Bool(true),
		},
	).Return(
		&autoscaling.TerminateInstanceInAutoScalingGroupOutput{
			Activity: &autoscalingtypes.Activity{Description: aws.String("Deleted instance")},
		},
		nil,
	)

	var expectedInstancesCount int32 = 2
	a.On("DescribeAutoScalingGroups",
		mock.Anything,
		&autoscaling.DescribeAutoScalingGroupsInput{
			AutoScalingGroupNames: []string{"test-asg"},
			MaxRecords:            aws.Int32(maxRecordsReturnedByAPI),
		},
	).Return(testSetASGInstanceLifecycle(testNamedDescribeAutoScalingGroupsOutput("test-asg", expectedInstancesCount, "test-instance-id", "second-test-instance-id"), autoscalingtypes.LifecycleStateTerminated), nil)

	// load ASG state into cache
	provider.Refresh(context.Background())

	initialSize, err := asgs[0].TargetSize(context.Background())
	assert.NoError(t, err)
	assert.Equal(t, expectedInstancesCount, int32(initialSize))

	// try deleting a node, but all of them are already in a
	// Terminated state, so we should see no calls to Terminate.
	node := &apiv1.Node{
		Spec: apiv1.NodeSpec{
			ProviderID: "aws:///us-east-1a/test-instance-id",
		},
	}
	err = asgs[0].DeleteNodes(context.Background(), []*apiv1.Node{node})
	assert.NoError(t, err)
	// we expect no calls to TerminateInstanceInAutoScalingGroup,
	// because the Node we tried to Delete was already terminating.
	a.AssertNumberOfCalls(t, "TerminateInstanceInAutoScalingGroup", 0)
	a.AssertNumberOfCalls(t, "DescribeAutoScalingGroups", 1)

	newSize, err := asgs[0].TargetSize(context.Background())
	assert.NoError(t, err)
	// we expect TargetSize to stay the same, even though there are
	// two instances in Terminated state - TargetSize was already
	// adjusted for them in a previous loop.
	assert.Equal(t, initialSize, newSize)
}

func TestDeleteNodesWithPlaceholder(t *testing.T) {
	a := &autoScalingMock{}
	provider := testProvider(t, newTestAwsManagerWithAsgs(t, a, nil, []string{"1:5:test-asg"}))
	asgs := provider.NodeGroups(context.Background())

	a.On("SetDesiredCapacity",
		mock.Anything,
		&autoscaling.SetDesiredCapacityInput{
			AutoScalingGroupName: aws.String(asgs[0].Id()),
			DesiredCapacity:      aws.Int32(1),
			HonorCooldown:        aws.Bool(false),
		},
	).Return(&autoscaling.SetDesiredCapacityOutput{}, nil)

	// Look up the current number of instances...
	var expectedInstancesCount int32 = 2
	a.On("DescribeAutoScalingGroups",
		mock.Anything,
		&autoscaling.DescribeAutoScalingGroupsInput{
			AutoScalingGroupNames: []string{"test-asg"},
			MaxRecords:            aws.Int32(maxRecordsReturnedByAPI),
		},
	).Run(func(args mock.Arguments) {
		// we expect the instance count to be 1 after the call to DeleteNodes
		expectedInstancesCount = 1
	}).Return(testNamedDescribeAutoScalingGroupsOutput("test-asg", expectedInstancesCount, "test-instance-id"), nil)

	a.On("DescribeScalingActivities",
		mock.Anything,
		&autoscaling.DescribeScalingActivitiesInput{
			AutoScalingGroupName: aws.String("test-asg"),
		},
	).Return(
		&autoscaling.DescribeScalingActivitiesOutput{},
		nil,
	)

	provider.Refresh(context.Background())

	initialSize, err := asgs[0].TargetSize(context.Background())
	assert.NoError(t, err)
	assert.Equal(t, 2, initialSize)

	node := &apiv1.Node{
		Spec: apiv1.NodeSpec{
			ProviderID: "aws:///us-east-1a/i-placeholder-test-asg-1",
		},
	}
	err = asgs[0].DeleteNodes(context.Background(), []*apiv1.Node{node})
	assert.NoError(t, err)
	a.AssertNumberOfCalls(t, "SetDesiredCapacity", 1)
	a.AssertNumberOfCalls(t, "DescribeAutoScalingGroups", 2)

	newSize, err := asgs[0].TargetSize(context.Background())
	assert.NoError(t, err)
	assert.Equal(t, 1, newSize)
}

func TestDeleteNodesAfterMultipleRefreshes(t *testing.T) {
	a := &autoScalingMock{}
	manager := newTestAwsManagerWithAsgs(t, a, nil, []string{"1:5:test-asg"})
	provider := testProvider(t, manager)
	asgs := provider.NodeGroups(context.Background())

	a.On("TerminateInstanceInAutoScalingGroup",
		mock.Anything,
		&autoscaling.TerminateInstanceInAutoScalingGroupInput{
			InstanceId:                     aws.String("test-instance-id"),
			ShouldDecrementDesiredCapacity: aws.Bool(true),
		},
	).Return(
		&autoscaling.TerminateInstanceInAutoScalingGroupOutput{
			Activity: &autoscalingtypes.Activity{Description: aws.String("Deleted instance")},
		},
		nil,
	)

	// Look up the current number of instances...
	a.On("DescribeAutoScalingGroups",
		mock.Anything,
		&autoscaling.DescribeAutoScalingGroupsInput{
			AutoScalingGroupNames: []string{"test-asg"},
			MaxRecords:            aws.Int32(maxRecordsReturnedByAPI),
		},
	).Return(testNamedDescribeAutoScalingGroupsOutput("test-asg", 2, "test-instance-id", "second-test-instance-id"), nil)

	provider.Refresh(context.Background())
	// Call the manager directly as otherwise the call would be a noop as its within less then 60s
	manager.forceRefresh()

	node := &apiv1.Node{
		Spec: apiv1.NodeSpec{
			ProviderID: "aws:///us-east-1a/test-instance-id",
		},
	}
	err := asgs[0].DeleteNodes(context.Background(), []*apiv1.Node{node})
	assert.NoError(t, err)
}

func TestGetResourceLimiter(t *testing.T) {
	mockAutoScaling := &autoScalingMock{}
	mockEC2 := &ec2Mock{}
	m := newTestAwsManagerWithMockServices(mockAutoScaling, mockEC2, nil, nil, nil)

	provider := testProvider(t, m)
	_, err := provider.GetResourceLimiter(context.Background())
	assert.NoError(t, err)
}

func TestCleanup(t *testing.T) {
	provider := testProvider(t, testAwsManager)
	err := provider.Cleanup(context.Background())
	assert.NoError(t, err)
}

func TestHasInstance(t *testing.T) {
	nodeStatus := "Healthy"
	mgr := &AwsManager{
		asgCache: &asgCache{
			registeredAsgs: make(map[AwsRef]*asg, 0),
			asgToInstances: make(map[AwsRef][]AwsInstanceRef),
			instanceToAsg:  make(map[AwsInstanceRef]*asg),
			interrupt:      make(chan struct{}),
			awsService:     &testAwsService,
			instanceStatus: map[AwsInstanceRef]*string{
				{
					ProviderID: "aws:///us-east-1a/test-instance-id",
					Name:       "test-instance-id",
				}: &nodeStatus,
			},
		},
		awsService: testAwsService,
	}
	provider := testProvider(t, mgr)

	// Case 1: correct node - present in AWS
	node1 := &apiv1.Node{
		ObjectMeta: metav1.ObjectMeta{
			Name: "node-1",
		},
		Spec: apiv1.NodeSpec{
			ProviderID: "aws:///us-east-1a/test-instance-id",
		},
	}
	present, err := provider.HasInstance(context.Background(), node1)
	assert.NoError(t, err)
	assert.True(t, present)

	// Case 2: incorrect node - fargate is unsupported
	node2 := &apiv1.Node{
		ObjectMeta: metav1.ObjectMeta{
			Name: "fargate-1",
		},
		Spec: apiv1.NodeSpec{
			ProviderID: "aws:///us-east-1a/test-instance-id",
		},
	}
	present, err = provider.HasInstance(context.Background(), node2)
	assert.Equal(t, cloudprovider.ErrNotImplemented, err)
	assert.True(t, present)

	// Case 3: correct node - not present in AWS
	node3 := &apiv1.Node{
		ObjectMeta: metav1.ObjectMeta{
			Name: "node-2",
		},
		Spec: apiv1.NodeSpec{
			ProviderID: "aws:///us-east-1a/test-instance-id-2",
		},
	}
	present, err = provider.HasInstance(context.Background(), node3)
	assert.ErrorContains(t, err, nodeNotPresentErr)
	assert.False(t, present)

	// Case 4: correct node - not autoscaled -> not present in AWS -> no warning
	node4 := &apiv1.Node{
		ObjectMeta: metav1.ObjectMeta{
			Name: "node-2",
			Annotations: map[string]string{
				"k8s.io/cluster-autoscaler-enabled": "false",
			},
		},
		Spec: apiv1.NodeSpec{
			ProviderID: "aws:///us-east-1a/test-instance-id-2",
		},
	}
	present, err = provider.HasInstance(context.Background(), node4)
	assert.NoError(t, err)
	assert.False(t, present)
}

func TestDeleteNodesWithPlaceholderAndStaleCache(t *testing.T) {
	// This test validates the scenario where ASG cache is not in sync with Autoscaling configuration.
	// we are taking an example where ASG size is 10, cache as 3 instances "i-0000", "i-0001" and "i-0002
	// But ASG has 6 instances i-0000 to i-10005. When DeleteInstances is called with 2 instances ("i-0000", "i-0001" )
	// and placeholders, CAS will terminate only these 2 instances after reducing ASG size by the count of placeholders

	a := &autoScalingMock{}
	provider := testProvider(t, newTestAwsManagerWithAsgs(t, a, nil, []string{"1:10:test-asg"}))
	asgs := provider.NodeGroups(context.Background())
	commonAsg := &asg{
		AwsRef:  AwsRef{Name: asgs[0].Id()},
		minSize: asgs[0].MinSize(context.Background()),
		maxSize: asgs[0].MaxSize(context.Background()),
	}

	// desired capacity will be set as 6 as ASG has 4 placeholders
	a.On("SetDesiredCapacity",
		mock.Anything,
		&autoscaling.SetDesiredCapacityInput{
			AutoScalingGroupName: aws.String(asgs[0].Id()),
			DesiredCapacity:      aws.Int32(6),
			HonorCooldown:        aws.Bool(false),
		},
	).Return(&autoscaling.SetDesiredCapacityOutput{}, nil)

	// Look up the current number of instances...
	var expectedInstancesCount int32 = 10
	a.On("DescribeAutoScalingGroups",
		mock.Anything,
		&autoscaling.DescribeAutoScalingGroupsInput{
			AutoScalingGroupNames: []string{"test-asg"},
			MaxRecords:            aws.Int32(maxRecordsReturnedByAPI),
		},
	).Run(func(args mock.Arguments) {
		expectedInstancesCount = 4
	}).Return(testNamedDescribeAutoScalingGroupsOutput("test-asg", expectedInstancesCount, "i-0000", "i-0001", "i-0002", "i-0003", "i-0004", "i-0005"), nil)

	a.On("DescribeScalingActivities",
		mock.Anything,
		&autoscaling.DescribeScalingActivitiesInput{
			AutoScalingGroupName: aws.String("test-asg"),
		},
	).Return(&autoscaling.DescribeScalingActivitiesOutput{}, nil)

	provider.Refresh(context.Background())

	initialSize, err := asgs[0].TargetSize(context.Background())
	assert.NoError(t, err)
	assert.Equal(t, 10, initialSize)

	var awsInstanceRefs []AwsInstanceRef
	instanceToAsg := make(map[AwsInstanceRef]*asg)

	var nodes []*apiv1.Node
	for i := 3; i <= 9; i++ {
		providerId := fmt.Sprintf("aws:///us-east-1a/i-placeholder-test-asg-%d", i)
		node := &apiv1.Node{
			Spec: apiv1.NodeSpec{
				ProviderID: providerId,
			},
		}
		nodes = append(nodes, node)
		awsInstanceRef := AwsInstanceRef{
			ProviderID: providerId,
			Name:       fmt.Sprintf("i-placeholder-test-asg-%d", i),
		}
		awsInstanceRefs = append(awsInstanceRefs, awsInstanceRef)
		instanceToAsg[awsInstanceRef] = commonAsg
	}

	for i := 0; i <= 2; i++ {
		providerId := fmt.Sprintf("aws:///us-east-1a/i-000%d", i)
		node := &apiv1.Node{
			Spec: apiv1.NodeSpec{
				ProviderID: providerId,
			},
		}
		// only setting 2 instances to be terminated out of 3 active instances
		if i < 2 {
			nodes = append(nodes, node)
			a.On("TerminateInstanceInAutoScalingGroup",
				mock.Anything,
				&autoscaling.TerminateInstanceInAutoScalingGroupInput{
					InstanceId:                     aws.String(fmt.Sprintf("i-000%d", i)),
					ShouldDecrementDesiredCapacity: aws.Bool(true),
				},
			).Return(
				&autoscaling.TerminateInstanceInAutoScalingGroupOutput{
					Activity: &autoscalingtypes.Activity{Description: aws.String("Deleted instance")},
				}, nil,
			)
		}
		awsInstanceRef := AwsInstanceRef{
			ProviderID: providerId,
			Name:       fmt.Sprintf("i-000%d", i),
		}
		awsInstanceRefs = append(awsInstanceRefs, awsInstanceRef)
		instanceToAsg[awsInstanceRef] = commonAsg
	}

	// modifying provider to bring disparity between ASG and cache
	provider.awsManager.asgCache.asgToInstances[AwsRef{Name: "test-asg"}] = awsInstanceRefs
	provider.awsManager.asgCache.instanceToAsg = instanceToAsg

	// calling delete nodes 2 nodes and remaining placeholders
	err = asgs[0].DeleteNodes(context.Background(), nodes)
	assert.NoError(t, err)
	a.AssertNumberOfCalls(t, "SetDesiredCapacity", 1)
	a.AssertNumberOfCalls(t, "DescribeAutoScalingGroups", 2)

	// This ensures only 2 instances are terminated which are mocked in this unit test
	a.AssertNumberOfCalls(t, "TerminateInstanceInAutoScalingGroup", 2)

}

func TestAwsNodeGroupTemplateNodeInfoDoesNotSetCSINode(t *testing.T) {
	const instanceTypeName = "m5.large"

	manager := &AwsManager{
		instanceTypes: map[string]*InstanceType{
			instanceTypeName: {
				InstanceType:   instanceTypeName,
				VCPU:           2,
				MemoryMb:       8192,
				Architecture:   "amd64",
				EBSVolumeLimit: 39,
			},
		},
	}

	origGetInstanceTypeFunc := getInstanceTypeForAsg
	defer func() { getInstanceTypeForAsg = origGetInstanceTypeFunc }()
	getInstanceTypeForAsg = func(_ *asgCache, _ *asg) (string, error) {
		return instanceTypeName, nil
	}

	ng := &AwsNodeGroup{
		awsManager: manager,
		asg: &asg{
			AwsRef:            AwsRef{Name: "test-asg"},
			AvailabilityZones: []string{"us-east-1a"},
			minSize:           0,
			maxSize:           5,
			curSize:           0,
		},
	}

	nodeInfo, err := ng.TemplateNodeInfo(context.Background())
	assert.NoError(t, err)
	assert.NotNil(t, nodeInfo)
	assert.Nil(t, nodeInfo.CSINode)
}

func TestAwsNodeGroupTemplateNodeInfoSetsCSINodeWhenDeclared(t *testing.T) {
	const instanceTypeName = "m5.large"

	manager := &AwsManager{
		instanceTypes: map[string]*InstanceType{
			instanceTypeName: {
				InstanceType:   instanceTypeName,
				VCPU:           2,
				MemoryMb:       8192,
				Architecture:   "amd64",
				EBSVolumeLimit: 39,
			},
		},
	}

	origGetInstanceTypeFunc := getInstanceTypeForAsg
	defer func() { getInstanceTypeForAsg = origGetInstanceTypeFunc }()
	getInstanceTypeForAsg = func(_ *asgCache, _ *asg) (string, error) {
		return instanceTypeName, nil
	}

	ng := &AwsNodeGroup{
		awsManager: manager,
		asg: &asg{
			AwsRef:            AwsRef{Name: "test-asg"},
			AvailabilityZones: []string{"us-east-1a"},
			minSize:           0,
			maxSize:           5,
			curSize:           0,
			Tags: []autoscalingtypes.TagDescription{
				{
					Key:   aws.String(csiDriverTagKey),
					Value: aws.String("ebs.csi.aws.com"),
				},
			},
		},
	}

	nodeInfo, err := ng.TemplateNodeInfo(context.Background())
	assert.NoError(t, err)
	assert.NotNil(t, nodeInfo)
	assert.NotNil(t, nodeInfo.CSINode)
	assert.Len(t, nodeInfo.CSINode.Spec.Drivers, 1)
	assert.Equal(t, "ebs.csi.aws.com", nodeInfo.CSINode.Spec.Drivers[0].Name)
	assert.NotNil(t, nodeInfo.CSINode.Spec.Drivers[0].Allocatable)
	assert.Equal(t, int32(39), *nodeInfo.CSINode.Spec.Drivers[0].Allocatable.Count)
}

func TestEFSOnlyExistingNodeStaysReadyWhenAWSTemplateHasNoCSINode(t *testing.T) {
	node := &apiv1.Node{
		ObjectMeta: metav1.ObjectMeta{Name: "efs-only-node"},
		Status: apiv1.NodeStatus{
			Conditions: []apiv1.NodeCondition{{Type: apiv1.NodeReady, Status: apiv1.ConditionTrue}},
		},
	}
	efsCSINode := &storagev1.CSINode{
		ObjectMeta: metav1.ObjectMeta{Name: node.Name},
		Spec: storagev1.CSINodeSpec{
			Drivers: []storagev1.CSINodeDriver{{Name: "efs.csi.aws.com", NodeID: node.Name}},
		},
	}
	template := framework.NewTestNodeInfo(&apiv1.Node{ObjectMeta: metav1.ObjectMeta{Name: "template"}})

	provider := testprovider.NewTestCloudProviderBuilder().Build()
	provider.AddAutoprovisionedNodeGroup("ng1", 0, 5, 1, "template")
	provider.AddNode("ng1", node)
	provider.SetMachineTemplates(map[string]*framework.NodeInfo{"template": template})

	processor := &customresources.CSICustomResourcesProcessor{}
	_, readyNodes := processor.FilterOutNodesWithUnreadyResources(
		context.Background(),
		&ca_context.AutoscalingContext{
			CloudProvider: provider,
			// An empty registry exercises the fallback to the cloud-provider template.
			TemplateNodeInfoRegistry: nodeinfosprovider.NewTemplateNodeInfoRegistry(nil),
		},
		[]*apiv1.Node{node}, []*apiv1.Node{node}, nil,
		csisnapshot.NewSnapshot(map[string]*storagev1.CSINode{node.Name: efsCSINode}),
	)

	assert.Nil(t, template.CSINode)
	assert.Equal(t, "efs.csi.aws.com", efsCSINode.Spec.Drivers[0].Name)
	assert.Len(t, readyNodes, 1)
	assert.Equal(t, apiv1.ConditionTrue, readyNodes[0].Status.Conditions[0].Status)
}
